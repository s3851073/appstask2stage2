# TimeTable
<h1 align=center>
<img src="logo-files/horizontal.png" width=50%>
</h1>

Timetable is an Android Application, which allows you to save timetable, homeworks and notes.

### Contribute

You are welcome to contribute with issues, pull requests and ideas. And to contribute to this project, please fork the project and submit a pull request. 

### Screenshots
<img alt="1 screenshot" src="screenshots/timetable_screenshot_1.jpg" width="31%" style="max-width:100%;"> &nbsp;&nbsp;&nbsp;&nbsp; <img alt="1 screenshot" src="screenshots/timetable_screenshot_2.jpg" width="31%" style="max-width:100%;"> &nbsp;&nbsp;&nbsp;&nbsp; <img alt="1 screenshot" src="screenshots/timetable_screenshot_3.jpg" width="31%" style="max-width:100%;">

### Licence

The source code is licensed under the [GNU v3 Public License](https://github.com/ulan17/TimeTable/blob/master/LICENSE). 
